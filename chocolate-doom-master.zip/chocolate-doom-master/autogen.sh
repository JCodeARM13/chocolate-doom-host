#!/bin/sh

autoreconf -fi
./configure "$@"
